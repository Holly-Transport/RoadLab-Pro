package com.softteco.roadlabpro.util;

public class ConvertQuantityUtil {

    public static float metersPerSecondsToKillometrPerHours(float value) {
        return value * 3.6f;
    }
}
