package com.softteco.roadlabpro.sync;

public enum DataSyncMode {
    ALL, PROJECT, ROAD
}
