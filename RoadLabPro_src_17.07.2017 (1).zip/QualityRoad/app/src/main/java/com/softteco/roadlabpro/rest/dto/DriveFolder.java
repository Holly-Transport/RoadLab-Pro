package com.softteco.roadlabpro.rest.dto;

public class DriveFolder extends FileItem {
}
