package com.softteco.roadlabpro.util;

/**
 * Created by Anton on 04.03.2015.
 */
public interface ExportToCSVResult {

    void onResultsAfterExporting(String[] executed);
}
